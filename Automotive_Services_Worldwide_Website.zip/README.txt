AUTOMOTIVE SERVICES WORLDWIDE
==============================

Files:
- index.html — complete responsive website
- style.css — website styling

Contact buttons:
WhatsApp: +57 350 506 6673
Telegram: https://t.me/carsolutions5

Suggested domain:
automotiveservicesworldwide.com

The domain name must be registered separately with a domain registrar. After registration, upload index.html and style.css to your hosting provider.
